/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.polimorfismofigurageometrica;

import java.util.Arrays;

/**
 *
 * @author LabSispc14
 */
public class RightTriangle extends FiguraGeometrica{
    
    public RightTriangle() {
    }

    public RightTriangle(double[] sizeSides) {
        super(3, sizeSides);
    }

    @Override
    public void area(double[] sizeSides) {
        double area = (double) (sizeSides[0] * sizeSides[1])/2;
        super.setArea(area);
    }

    @Override
    public void perimeter(double[] sizeSides) {
        double perimetro = (double) sizeSides[0] + sizeSides[1] + sizeSides[2];
        super.setPerimetro(perimetro);
    }
    
    @Override
    public String toString() {
        return "RightTriangle{" + "Lados=" + super.getSides() + ", Medidas de los lados=" + Arrays.toString(super.getSizeSides()) + ", Area=" + super.getArea() + ", Perimetro=" + super.getPerimetro() +'}';
    }
}

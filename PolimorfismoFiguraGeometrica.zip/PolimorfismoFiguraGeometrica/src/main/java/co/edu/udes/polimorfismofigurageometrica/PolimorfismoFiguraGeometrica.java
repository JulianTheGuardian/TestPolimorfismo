/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package co.edu.udes.polimorfismofigurageometrica;

import java.util.Scanner;

/**
 *
 * @author LabSispc14
 */
public class PolimorfismoFiguraGeometrica {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int menu;
        double[] sizeSides;
        
        while(true){
            
            System.out.println("Bienvenido, ¿con que figura geometrica le gustaria trabajar el dia de hoy?");
            System.out.println("1. Circulo");
            System.out.println("2. Triangulo");
            System.out.println("3. Cuadrado");
            System.out.println("4. Salir");           
            menu = scanner.nextInt();
            scanner.nextLine();
            
            if (menu == 4){
                System.out.println("Muchas gracias por usar este servicio.");
                System.exit(0);
            }
            
            switch(menu){
                
                case 1:
                    sizeSides = new double[1];
                    
                    System.out.println("Ingrese el radio del circulo.");
                    sizeSides[0] = scanner.nextDouble();
                    scanner.nextLine();
                    
                    FiguraGeometrica myCircle = new Circle(sizeSides);
                    
                    myCircle.area(myCircle.getSizeSides());
                    
                    myCircle.perimeter(myCircle.getSizeSides());
                    
                    System.out.println(myCircle.toString());
                    
                    break;
                
                case 2:
                    sizeSides = new double[3];
                    
                    System.out.println("Ingrese la base del triangulo rectangulo.");
                    sizeSides[0] = scanner.nextDouble();
                    scanner.nextLine();
                    
                    System.out.println("Ingrese la altura del triangulo rectangulo.");
                    sizeSides[1] = scanner.nextDouble();
                    scanner.nextLine();
                    
                    sizeSides[2] = Math.sqrt( (Math.pow(sizeSides[0], 2) + Math.pow(sizeSides[1], 2)));
                    
                    FiguraGeometrica myRightTriangle = new RightTriangle(sizeSides);
                    
                    myRightTriangle.area(myRightTriangle.getSizeSides());
                    
                    myRightTriangle.perimeter(myRightTriangle.getSizeSides());
                    
                    System.out.println(myRightTriangle.toString());
                    
                    break;
                
                case 3:
                    sizeSides = new double[4];
                    
                    System.out.println("Ingrese el lado del cuadrado.");
                    sizeSides[0] = scanner.nextDouble();
                    scanner.nextLine();
                    
                    sizeSides[1] = sizeSides[0];
                    sizeSides[2] = sizeSides[0];
                    sizeSides[3] = sizeSides[0];
                            
                    FiguraGeometrica mySquare = new Square(sizeSides);
                    
                    mySquare.area(mySquare.getSizeSides());
                    
                    mySquare.perimeter(mySquare.getSizeSides());
                    
                    System.out.println(mySquare.toString());

                    break;
            }
            System.out.println("");
        }    
    }
}

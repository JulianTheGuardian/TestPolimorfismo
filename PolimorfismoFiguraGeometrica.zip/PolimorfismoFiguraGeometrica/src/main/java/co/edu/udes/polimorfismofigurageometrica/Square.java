/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.polimorfismofigurageometrica;

import java.util.Arrays;

/**
 *
 * @author LabSispc14
 */
public class Square extends FiguraGeometrica{

    public Square() {
    }

    public Square(double[] sizeSides) {
        super(4, sizeSides);
    }

    @Override
    public void area(double[] sizeSides) {
        double area = (double) sizeSides[0] * sizeSides[0];
        super.setArea(area);
    }

    @Override
    public void perimeter(double[] sizeSides) {
        double perimetro = (double) sizeSides[0] * 4;
        super.setPerimetro(perimetro);
    }

    @Override
    public String toString() {
        return "Square{" + "Lados=" + super.getSides() + ", Medidas de los lados=" + Arrays.toString(super.getSizeSides()) + ", Area=" + super.getArea() + ", Perimetro=" + super.getPerimetro() +'}';
    }
    
    
}

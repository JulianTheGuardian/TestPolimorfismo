/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.polimorfismofigurageometrica;

/**
 *
 * @author LabSispc14
 */
public class FiguraGeometrica {
    private int sides;
    private double[] sizeSides;
    private double area;
    private double perimetro;

    public FiguraGeometrica() {
    }

    public FiguraGeometrica(int sides, double[] sizeSides) {
        this.sides = sides;
        this.sizeSides = sizeSides;
    }

    public int getSides() {
        return sides;
    }

    public void setSides(int sides) {
        this.sides = sides;
    }

    public double[] getSizeSides() {
        return sizeSides;
    }

    public void setSizeSides(double[] sizeSides) {
        this.sizeSides = sizeSides;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    public void perimeter(double[] sizeSides) {
        
    }
    
    public void area(double[] sizeSides) {
        
    }    
    
}

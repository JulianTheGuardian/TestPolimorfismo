/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.polimorfismofigurageometrica;

import java.util.Arrays;

/**
 *
 * @author LabSispc14
 */
public class Circle extends FiguraGeometrica{
  
    public Circle() {
    }

    public Circle(double[] sizeSides) {
        super(0, sizeSides);
    }

    @Override
    public void area(double[] sizeSides) {
        double area = (double) Math.PI * sizeSides[0];
        super.setArea(area);
    }

    @Override
    public void perimeter(double[] sizeSides) {
        double perimetro = (double) 2 * Math.PI * sizeSides[0];
        super.setPerimetro(perimetro);
    }

    @Override
    public String toString() {
        return "RightTriangle{" + "Radio=" + Arrays.toString(super.getSizeSides()) + ", Area=" + super.getArea() + ", Perimetro=" + super.getPerimetro() +'}';
    }
    
}
